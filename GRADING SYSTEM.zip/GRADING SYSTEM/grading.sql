-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2020 at 08:08 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grading`
--

-- --------------------------------------------------------

--
-- Table structure for table `bsc_in_communication_&_journalism`
--

CREATE TABLE `bsc_in_communication_&_journalism` (
  `ID` int(11) NOT NULL,
  `regno` varchar(255) DEFAULT NULL,
  `CMS 311` varchar(255) DEFAULT NULL,
  `CMS 321` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bsc_in_informatics`
--

CREATE TABLE `bsc_in_informatics` (
  `ID` int(100) NOT NULL,
  `regno` varchar(255) NOT NULL,
  `INF_310` int(255) DEFAULT NULL,
  `INF_313` int(255) DEFAULT NULL,
  `INF_443` int(255) DEFAULT NULL,
  `INF_413` int(255) DEFAULT NULL,
  `INF_471` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `ID` int(255) NOT NULL,
  `COURSE` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`ID`, `COURSE`) VALUES
(1, 'BED IN LITERATURE'),
(2, 'BED IN KISWAHILI');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `ID` int(255) NOT NULL,
  `REGNO` varchar(255) DEFAULT NULL,
  `INF_310` varchar(255) DEFAULT NULL,
  `INF_313` varchar(255) DEFAULT NULL,
  `INF_413` varchar(255) DEFAULT NULL,
  `INF_443` varchar(255) DEFAULT NULL,
  `INF_471` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`ID`, `REGNO`, `INF_310`, `INF_313`, `INF_413`, `INF_443`, `INF_471`) VALUES
(1, 'INF/6002/2017', 'A', 'A', '0', 'C', '0');

-- --------------------------------------------------------

--
-- Table structure for table `infocoms`
--

CREATE TABLE `infocoms` (
  `ID` int(255) NOT NULL,
  `COURSE` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infocoms`
--

INSERT INTO `infocoms` (`ID`, `COURSE`) VALUES
(1, 'BSC IN INFORMATICS'),
(2, 'BSC IN INFORMATION SCIENCE'),
(3, 'BSC IN COMMUNICATION & JOURNALISM'),
(4, 'BSC IN COMMUNICATION & PUBLIC RELATIONS'),
(5, 'BSC IN HEALTH RECORDS'),
(6, 'BSC IN LIBRARY SCIENCE');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Name` varchar(255) NOT NULL,
  `username` varchar(200) NOT NULL,
  `NationalId` int(255) NOT NULL,
  `EmployeeNo` varchar(255) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Name`, `username`, `NationalId`, `EmployeeNo`, `password`) VALUES
('', 'faith', 0, '', '1234'),
('JOYCE JERUTO', 'JOY', 12345678, '12/34', '4569'),
('MARIA WAMBUA MBULI', 'MARIA', 123456789, '12/36', '12345 '),
('', 'mary', 0, '', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` int(11) NOT NULL,
  `regno` varchar(15) NOT NULL,
  `total marks` int(3) NOT NULL,
  `grade` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `regno` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `school` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `academic_year` varchar(255) NOT NULL,
  `Y_O_S` int(255) DEFAULT NULL,
  `sem` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `regno`, `name`, `school`, `course`, `academic_year`, `Y_O_S`, `sem`) VALUES
(1, 'INF/6002/2017', 'MARGARET ACHIENG ONYANGO', 'SCHOOL OF INFOCOMS', 'BSC_IN_INFORMATICS', '2020/2021', 3, 2),
(2, 'INF/002/2017', 'MARTIN MURIUNGI', 'SCHOOL OF INFOCOMS', 'BSC IN INFORMATICS', '2020/2021', 3, 2),
(3, '', '', 'SCHOOL OF INFOCOMS', 'BSC IN INFORMATICS', '2020/2021', 3, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bsc_in_communication_&_journalism`
--
ALTER TABLE `bsc_in_communication_&_journalism`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `bsc_in_informatics`
--
ALTER TABLE `bsc_in_informatics`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `infocoms`
--
ALTER TABLE `infocoms`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`(100));

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `regno` (`regno`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bsc_in_communication_&_journalism`
--
ALTER TABLE `bsc_in_communication_&_journalism`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bsc_in_informatics`
--
ALTER TABLE `bsc_in_informatics`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `infocoms`
--
ALTER TABLE `infocoms`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
