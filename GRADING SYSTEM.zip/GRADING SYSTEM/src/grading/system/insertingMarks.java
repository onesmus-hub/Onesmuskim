///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package grading.system;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
///**
// *
// * @author user
// */
//public class insertingMarks extends student {
//    public void insertingMarks(){
//    Connection con;
//    PreparedStatement ps;
//    try{
//    con=connector.getConnection();
//    ps=con.prepareStatement("select course from student");
//    ResultSet rst=ps.executeQuery();
//    if(rst.next()){
//
//    
//    }//end of 1st if statement
//    else{
//    
//    }//end of 1st else statemnet
//    
//    
//    }catch(Exception e)
//    {
//       
//        System.out.println("ERR: "+ e);
//    }
//    
//    }
//    
//}
