/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grading.system;

import static grading.system.student.jTextFieldRegNoS;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author user
 */
public class fillTranscript extends Transcripts {
   
    public void check(){
       try {

           
    Connection con;
    con=connector.getConnection();
    PreparedStatement ps;
    ps=con.prepareStatement("select * from student where regno='"+ jTextFieldRegNoS.getText()+"'");
    ResultSet rst=ps.executeQuery();
    if(rst.next())
    {
    jTextFieldUserName.setText(rst.getString("name"));
    jTextFieldSchool.setText(rst.getString("school"));
    jTextFieldProgramme.setText(rst.getString("course"));   
    }
}catch(Exception e){System.out.println("Error "+e);

}
}
    
    
}
