///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package grading.system;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import javax.swing.JTable;
//import javax.swing.table.DefaultTableModel;
//import java.sql.ResultSetMetaData;
//import java.util.ArrayList;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.Vector;
//import javax.swing.JOptionPane;
//
//
///**
// *
// * @author user
// */
//public class TableGenerator {
//    Connection con;
//    PreparedStatement ps;
//    
//          try{
//            con=connector.getConnection();
//            Statement stmt=con.createStatement();
//            ResultSet rst=stmt.executeQuery("SELECT * FROM student ");
//           
//            
//            ResultSetMetaData metadata=rst.getMetaData();
//            int columnCount= metadata.getColumnCount();
//            // 
//            
//            for(int i=3;i<=columnCount;i++){
//                String columnName=metadata.getColumnName(i); 
//        
////            ps=con.prepareStatement("SELECT ID, SUM("+ columnName +") FROM "+ jLabelCourse.getText()+"WHERE ID="+jTextFieldId.getText()+" GROUP BY ID");
////                ps=con.prepareStatement("SELECT  SUM("+ jLabelCourse.getText()+"."+metadata.getColumnName(i) +") FROM "+ jLabelCourse.getText()+" WHERE ID= "+jTextFieldId.getText());
//                 ps=con.prepareStatement("SELECT ID, SUM(IF(ID=" +jTextFieldId.getText()+" " +metadata.getColumnName(i)+") FROM "+ jLabelCourse.getText()+" AS TOTAL , SUM("+metadata.getColumnName(i)+") AS TOT");
//                rst=ps.executeQuery();
//            
//          if(rst.next()){
//             
//              int t=rst.getInt("SUM("+metadata.getColumnName(i)+")");
//             JOptionPane.showMessageDialog(null,"new "+t);
//             
//          }
//         
//            }
//            
//            
//          
//        catch(Exception ex) {
//         System.out.println("ERROR" + ex);
//         
//         
//        }
//        
//  
//}
//}
//
//
//
//
