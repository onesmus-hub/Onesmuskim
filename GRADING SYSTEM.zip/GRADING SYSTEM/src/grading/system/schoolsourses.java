/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grading.system;

/**
 *
 * @author user
 */
public class schoolsourses extends addNewStudent{
    private String Course;
    public void setCourse(String Course){
    this.Course=Course;
           
    String courseDb=jComboBoxCourse.getSelectedItem().toString();
       if(courseDb.equals("BSC IN INFORMATICS")){
        Course="bsc_in_informatics"; 
       }
       else if(courseDb.equals("BSC IN COMMUNICATION ")){
        Course="bsc_in_communication_&_journalism"; 
       }
       else if(courseDb.equals("BSC IN INFORMATICS")){
        Course="bsc_in_communication_&_journalism"; 
       }
    
    }
public String getCourse(){

return Course;
}
}
